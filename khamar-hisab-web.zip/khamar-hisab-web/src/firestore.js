import {
  collection,
  doc,
  onSnapshot,
  addDoc,
  deleteDoc,
  setDoc,
  writeBatch,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "./firebase";

/** একটি কালেকশনে রিয়েল-টাইম সাবস্ক্রাইব করে — যেকোনো পরিবর্তন হলেই cb() কল হবে */
export function subscribeCol(path, cb, onError) {
  return onSnapshot(
    collection(db, path),
    (snap) => cb(snap.docs.map((d) => ({ id: d.id, ...d.data() }))),
    (err) => {
      console.error(`subscribeCol(${path})`, err);
      if (onError) onError(err);
    }
  );
}

/** একটি একক ডকুমেন্টে রিয়েল-টাইম সাবস্ক্রাইব করে (যেমন settings/app) */
export function subscribeDocPath(path, cb, onError) {
  return onSnapshot(
    doc(db, path),
    (snap) => cb(snap.exists() ? snap.data() : null),
    (err) => {
      console.error(`subscribeDocPath(${path})`, err);
      if (onError) onError(err);
    }
  );
}

export function addItem(path, data) {
  return addDoc(collection(db, path), { ...data, createdAt: serverTimestamp() });
}

export function removeItem(path, id) {
  return deleteDoc(doc(db, `${path}/${id}`));
}

export async function clearCollection(path, ids) {
  if (!ids.length) return;
  const batch = writeBatch(db);
  ids.forEach((id) => batch.delete(doc(db, `${path}/${id}`)));
  await batch.commit();
}

export function setDocData(path, data) {
  return setDoc(doc(db, path), data, { merge: true });
}

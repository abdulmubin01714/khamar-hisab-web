import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// ⚠️ এখানে আপনার নিজের Firebase প্রজেক্টের কনফিগ বসান।
// Firebase Console → Project settings → General → "Your apps" → Web app (</>）
// থেকে এই অবজেক্টটি কপি করে নিচেরটির জায়গায় বসিয়ে দিন।
// এই কনফিগ ভ্যালুগুলো গোপনীয় (secret) নয় — ব্রাউজারে প্রকাশিত থাকা স্বাভাবিক;
// প্রকৃত নিরাপত্তা আসে Firestore-এর security rules (firestore.rules) থেকে।
const firebaseConfig = {
  apiKey: "AIzaSyBy__iG6RYhCbcvR8FuQ4qHbCvko6X4Nko",
  authDomain: "khamar-hisab-69cc5.firebaseapp.com",
  projectId: "khamar-hisab-69cc5",
  storageBucket: "khamar-hisab-69cc5.firebasestorage.app",
  messagingSenderId: "713119245953",
  appId: "1:713119245953:web:633e65e5d6d6d7a2098f80",
  measurementId: "G-8WLLNZWG2C",
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

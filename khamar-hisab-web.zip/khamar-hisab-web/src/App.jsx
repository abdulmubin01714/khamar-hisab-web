import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { Home, Users, PawPrint, Egg, MessageCircle, Lock, Unlock } from "lucide-react";
import { T, FARMS, emptyRecords } from "./theme";
import { taka, sum } from "./utils";
import { subscribeCol, subscribeDocPath, addItem as fsAddItem, removeItem as fsRemoveItem, clearCollection, setDocData } from "./firestore";
import PinModal from "./components/PinModal";
import PrintArea from "./components/PrintArea";
import Dashboard from "./components/Dashboard";
import FarmPage from "./components/FarmPage";
import WhatsAppTab from "./components/WhatsAppTab";
import MembersPage from "./components/MembersPage";

const LOCAL_PIN_CACHE_KEY = "khamar-editor-pin-cache";

export default function App() {
  const [loaded, setLoaded] = useState(false);
  const [members, setMembers] = useState([]);
  const [whatsapp, setWhatsapp] = useState([]);
  const [records, setRecords] = useState({ cow: emptyRecords(), chicken: emptyRecords(), goat: emptyRecords() });
  const [pin, setPin] = useState(null); // null = না জানা, "" = কোনো PIN সেট নেই
  const [isEditor, setIsEditor] = useState(false);
  const [modal, setModal] = useState(null); // 'unlock' | 'setup' | 'change'
  const [modalError, setModalError] = useState("");
  const [printJob, setPrintJob] = useState(null);
  const [tab, setTab] = useState("dashboard");
  const [subTab, setSubTab] = useState("ledger");
  const printTimer = useRef(null);
  const readyFlags = useRef({ members: false, whatsapp: false, pin: false });

  const markReady = (key) => {
    readyFlags.current[key] = true;
    if (readyFlags.current.members && readyFlags.current.whatsapp && readyFlags.current.pin) {
      setLoaded(true);
    }
  };

  // ---------- রিয়েল-টাইম সাবস্ক্রিপশন ----------
  useEffect(() => {
    const unsubs = [];

    unsubs.push(
      subscribeCol("members", (list) => {
        setMembers(list);
        markReady("members");
      })
    );
    unsubs.push(
      subscribeCol("whatsappContacts", (list) => {
        setWhatsapp(list);
        markReady("whatsapp");
      })
    );
    unsubs.push(
      subscribeDocPath("settings/app", (data) => {
        const serverPin = data && data.pin ? data.pin : "";
        setPin(serverPin);
        const cached = localStorage.getItem(LOCAL_PIN_CACHE_KEY) || "";
        if (serverPin && cached && cached === serverPin) setIsEditor(true);
        if (serverPin && cached && cached !== serverPin) setIsEditor(false);
        markReady("pin");
      })
    );

    Object.keys(FARMS).forEach((key) => {
      ["deposits", "expenses", "incomes"].forEach((sub) => {
        unsubs.push(
          subscribeCol(`farms/${key}/${sub}`, (items) => {
            setRecords((prev) => ({ ...prev, [key]: { ...prev[key], [sub]: items } }));
          })
        );
      });
    });

    return () => unsubs.forEach((u) => u && u());
  }, []);

  useEffect(() => {
    return () => printTimer.current && clearTimeout(printTimer.current);
  }, []);

  // ---------- জেনেরিক ডেটা অ্যাকশন ----------
  const addMemberFn = (data) => fsAddItem("members", data);
  const removeMemberFn = (id) => fsRemoveItem("members", id);

  const addWhatsapp = (data) => fsAddItem("whatsappContacts", data);
  const removeWhatsapp = (id) => fsRemoveItem("whatsappContacts", id);
  const clearWhatsapp = (ids) => clearCollection("whatsappContacts", ids);

  const addFarmItem = (farmKey, sub, data) => fsAddItem(`farms/${farmKey}/${sub}`, data);
  const removeFarmItem = (farmKey, sub, id) => fsRemoveItem(`farms/${farmKey}/${sub}`, id);
  const clearFarmItems = (farmKey, sub, ids) => clearCollection(`farms/${farmKey}/${sub}`, ids);

  // ---------- PIN হ্যান্ডলিং ----------
  const openUnlock = () => {
    setModalError("");
    setModal(pin ? "unlock" : "setup");
  };
  const openChangePin = () => {
    setModalError("");
    setModal("change");
  };
  const lockNow = () => {
    setIsEditor(false);
    localStorage.removeItem(LOCAL_PIN_CACHE_KEY);
  };
  const handleModalSubmit = async (payload) => {
    if (payload.error) {
      setModalError(payload.error);
      return;
    }
    if (modal === "unlock") {
      if (payload.pin === pin) {
        setIsEditor(true);
        localStorage.setItem(LOCAL_PIN_CACHE_KEY, payload.pin);
        setModal(null);
      } else {
        setModalError("ভুল PIN, আবার চেষ্টা করুন");
      }
    } else if (modal === "setup") {
      await setDocData("settings/app", { pin: payload.newPin });
      localStorage.setItem(LOCAL_PIN_CACHE_KEY, payload.newPin);
      setIsEditor(true);
      setModal(null);
    } else if (modal === "change") {
      if (payload.oldPin !== pin) {
        setModalError("বর্তমান PIN সঠিক নয়");
        return;
      }
      await setDocData("settings/app", { pin: payload.newPin });
      localStorage.setItem(LOCAL_PIN_CACHE_KEY, payload.newPin);
      setModal(null);
    }
  };

  // ---------- PDF/প্রিন্ট ----------
  const requestPrint = (job) => {
    setPrintJob(job);
    printTimer.current = setTimeout(() => {
      try {
        window.print();
      } catch (e) {}
    }, 150);
  };

  // ---------- মেম্বার ফর্ম ----------
  const [memberForm, setMemberForm] = useState({ name: "", phone: "", joinDate: new Date().toISOString().slice(0, 10) });
  const addMember = () => {
    if (!isEditor || !memberForm.name.trim()) return;
    addMemberFn(memberForm);
    setMemberForm({ name: "", phone: "", joinDate: new Date().toISOString().slice(0, 10) });
  };
  const removeMember = (id) => isEditor && removeMemberFn(id);

  // ---------- হিসাব ----------
  const farmTotals = useMemo(() => {
    const out = {};
    for (const key of Object.keys(FARMS)) {
      const r = records[key];
      const deposit = sum(r.deposits.filter((d) => d.type === "জমা"), (d) => d.amount);
      const withdraw = sum(r.deposits.filter((d) => d.type === "উত্তোলন"), (d) => d.amount);
      const expense = sum(r.expenses, (e) => e.amount);
      const income = sum(r.incomes, (i) => i.amount);
      out[key] = { deposit, withdraw, capital: deposit - withdraw, expense, income, profit: income - expense };
    }
    return out;
  }, [records]);

  const memberCapital = useCallback(
    (memberId, farmKey) => {
      const r = records[farmKey];
      const d = sum(r.deposits.filter((x) => x.memberId === memberId && x.type === "জমা"), (x) => x.amount);
      const w = sum(r.deposits.filter((x) => x.memberId === memberId && x.type === "উত্তোলন"), (x) => x.amount);
      return d - w;
    },
    [records]
  );
  const memberTotalCapital = useCallback(
    (memberId) => Object.keys(FARMS).reduce((a, k) => a + memberCapital(memberId, k), 0),
    [memberCapital]
  );

  // ---------- সম্পূর্ণ হিসাব রিপোর্ট ----------
  const buildFullReportJob = () => {
    const grand = Object.values(farmTotals).reduce(
      (a, t) => ({ capital: a.capital + t.capital, income: a.income + t.income, expense: a.expense + t.expense, profit: a.profit + t.profit }),
      { capital: 0, income: 0, expense: 0, profit: 0 }
    );

    const sections = [
      {
        heading: "সার্বিক সারসংক্ষেপ",
        summaryRows: [
          ["মোট সদস্য", members.length.toString()],
          ["সর্বমোট সদস্য-মূলধন", taka(grand.capital)],
          ["সর্বমোট আয়", taka(grand.income)],
          ["সর্বমোট খরচ", taka(grand.expense)],
          ["সর্বমোট লাভ/ক্ষতি", taka(grand.profit)],
        ],
      },
    ];

    Object.entries(FARMS).forEach(([key, farm]) => {
      const t = farmTotals[key];
      const r = records[key];
      const nameOf = (id) => members.find((m) => m.id === id)?.name || "অজানা সদস্য";
      const deposits = [...r.deposits].sort((a, b) => (a.date < b.date ? 1 : -1));
      const expenses = [...r.expenses].sort((a, b) => (a.date < b.date ? 1 : -1));
      const incomes = [...r.incomes].sort((a, b) => (a.date < b.date ? 1 : -1));

      sections.push({
        heading: farm.label,
        summaryRows: [
          ["মোট জমা", taka(t.deposit)],
          ["মোট উত্তোলন", taka(t.withdraw)],
          ["সদস্য-মূলধন (নিট)", taka(t.capital)],
          ["মোট আয়", taka(t.income)],
          ["মোট খরচ", taka(t.expense)],
          ["নিট লাভ/ক্ষতি", taka(t.profit)],
        ],
        tables: [
          deposits.length
            ? {
                title: "জমা/উত্তোলন",
                columns: [
                  { key: "date", label: "তারিখ" },
                  { key: "name", label: "সদস্য" },
                  { key: "type", label: "ধরন" },
                  { key: "amount", label: "পরিমাণ" },
                ],
                rows: deposits.map((d) => ({ date: d.date, name: nameOf(d.memberId), type: d.type, amount: taka(d.amount) })),
              }
            : null,
          expenses.length
            ? {
                title: "খরচ",
                columns: [
                  { key: "date", label: "তারিখ" },
                  { key: "category", label: "খাত" },
                  { key: "amount", label: "পরিমাণ" },
                ],
                rows: expenses.map((e) => ({ date: e.date, category: e.category, amount: taka(e.amount) })),
              }
            : null,
          incomes.length
            ? {
                title: "আয়",
                columns: [
                  { key: "date", label: "তারিখ" },
                  { key: "category", label: "খাত" },
                  { key: "amount", label: "পরিমাণ" },
                ],
                rows: incomes.map((inc) => ({ date: inc.date, category: inc.category, amount: taka(inc.amount) })),
              }
            : null,
        ].filter(Boolean),
      });
    });

    if (members.length > 0) {
      sections.push({
        heading: "সদস্য অনুযায়ী মূলধন (সকল খামার)",
        tables: [
          {
            columns: [
              { key: "name", label: "নাম" },
              { key: "cow", label: "গরু" },
              { key: "chicken", label: "মুরগি" },
              { key: "goat", label: "ছাগল" },
              { key: "total", label: "সর্বমোট" },
            ],
            rows: members.map((m) => ({
              name: m.name,
              cow: taka(memberCapital(m.id, "cow")),
              chicken: taka(memberCapital(m.id, "chicken")),
              goat: taka(memberCapital(m.id, "goat")),
              total: taka(memberTotalCapital(m.id)),
            })),
          },
        ],
      });
    }

    return { title: "সম্পূর্ণ হিসাব রিপোর্ট — সকল খামার", sections };
  };

  if (!loaded) {
    return (
      <div style={{ padding: 40, textAlign: "center", color: T.inkSoft, fontFamily: "'Hind Siliguri', sans-serif" }}>
        হিসাবের খাতা খোলা হচ্ছে…
      </div>
    );
  }

  return (
    <div style={{ fontFamily: "'Hind Siliguri', sans-serif", background: T.paper, minHeight: "100vh", color: T.ink }}>
      <div className="app-normal">
        {/* হেডার */}
        <div
          style={{
            padding: "18px 18px 14px",
            background: T.paperDark,
            borderBottom: `2px solid ${T.margin}`,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
            gap: 10,
            flexWrap: "wrap",
          }}
        >
          <div>
            <h1 style={{ margin: 0, fontFamily: "'Tiro Bangla', serif", fontSize: 24, color: T.ink }}>হিসাবের খাতা</h1>
            <p style={{ margin: "4px 0 0", fontSize: 13, color: T.inkSoft }}>সমবায় খামার ব্যবস্থাপনা — গরু · মুরগি · ছাগল</p>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            {isEditor ? (
              <>
                <span
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 4,
                    fontSize: 12,
                    color: T.goat,
                    fontWeight: 600,
                    background: T.goat + "1a",
                    padding: "5px 9px",
                    borderRadius: 3,
                  }}
                >
                  <Unlock size={13} /> এডিট মোড
                </span>
                <button onClick={openChangePin} style={{ border: "none", background: "transparent", color: T.inkSoft, cursor: "pointer", fontSize: 12 }}>
                  PIN বদলান
                </button>
                <button
                  onClick={lockNow}
                  style={{ border: `1px solid ${T.border}`, background: "transparent", color: T.inkSoft, borderRadius: 3, padding: "5px 9px", fontSize: 12, cursor: "pointer" }}
                >
                  লক করুন
                </button>
              </>
            ) : (
              <button
                onClick={openUnlock}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 5,
                  border: `1px solid ${T.gold}`,
                  background: "transparent",
                  color: T.gold,
                  borderRadius: 3,
                  padding: "6px 10px",
                  fontSize: 12.5,
                  cursor: "pointer",
                  fontWeight: 600,
                }}
              >
                <Lock size={13} /> শুধু দেখা — এডিট মোড
              </button>
            )}
          </div>
        </div>

        {/* প্রধান ট্যাব */}
        <div style={{ display: "flex", gap: 4, padding: "10px 12px 0", overflowX: "auto" }}>
          {[
            { key: "dashboard", label: "ড্যাশবোর্ড", color: T.neutral, Icon: Home },
            { key: "cow", label: FARMS.cow.label, color: T.cow, Icon: PawPrint },
            { key: "chicken", label: FARMS.chicken.label, color: T.chicken, Icon: Egg },
            { key: "goat", label: FARMS.goat.label, color: T.goat, Icon: PawPrint },
            { key: "whatsapp", label: "WhatsApp নাম্বার", color: T.whatsapp, Icon: MessageCircle },
            { key: "members", label: "সদস্যগণ", color: T.gold, Icon: Users },
          ].map(({ key, label, color, Icon }) => {
            const active = tab === key;
            return (
              <button
                key={key}
                onClick={() => {
                  setTab(key);
                  setSubTab("ledger");
                }}
                style={{
                  flex: "0 0 auto",
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  padding: "9px 14px",
                  fontSize: 13.5,
                  fontWeight: 600,
                  border: "none",
                  borderRadius: "6px 6px 0 0",
                  cursor: "pointer",
                  background: active ? T.card : "transparent",
                  color: active ? color : T.inkSoft,
                  boxShadow: active ? `inset 0 -3px 0 ${color}` : "none",
                  fontFamily: "'Hind Siliguri', sans-serif",
                }}
              >
                <Icon size={15} color={active ? color : T.inkSoft} />
                {label}
              </button>
            );
          })}
        </div>

        {/* কন্টেন্ট */}
        <div style={{ padding: 14 }}>
          {tab === "dashboard" && (
            <Dashboard totals={farmTotals} memberCount={members.length} onDownloadFull={() => requestPrint(buildFullReportJob())} />
          )}

          {["cow", "chicken", "goat"].includes(tab) && (
            <FarmPage
              farmKey={tab}
              farm={FARMS[tab]}
              totals={farmTotals[tab]}
              records={records[tab]}
              members={members}
              subTab={subTab}
              setSubTab={setSubTab}
              addItem={addFarmItem}
              removeItem={removeFarmItem}
              clearAll={(sub, ids) => clearFarmItems(tab, sub, ids)}
              memberCapital={memberCapital}
              isEditor={isEditor}
              onRequestUnlock={openUnlock}
              requestPrint={requestPrint}
            />
          )}

          {tab === "whatsapp" && (
            <WhatsAppTab
              items={whatsapp}
              addItem={addWhatsapp}
              removeItem={removeWhatsapp}
              clearAll={clearWhatsapp}
              isEditor={isEditor}
              onRequestUnlock={openUnlock}
              requestPrint={requestPrint}
            />
          )}

          {tab === "members" && (
            <MembersPage
              members={members}
              memberForm={memberForm}
              setMemberForm={setMemberForm}
              addMember={addMember}
              removeMember={removeMember}
              memberTotalCapital={memberTotalCapital}
              memberCapital={memberCapital}
              isEditor={isEditor}
              onRequestUnlock={openUnlock}
              requestPrint={requestPrint}
            />
          )}
        </div>

        <p style={{ textAlign: "center", fontSize: 11.5, color: T.inkSoft, padding: "6px 10px 16px" }}>
          এই খাতার তথ্য Firebase-এ নিরাপদে সংরক্ষিত থাকে এবং সবার পাতায় সাথে সাথে (রিয়েল-টাইম) আপডেট হয়। এডিট করতে PIN প্রয়োজন।
        </p>
      </div>

      <PrintArea job={printJob} />

      {modal && <PinModal mode={modal} error={modalError} onClose={() => setModal(null)} onSubmit={handleModalSubmit} />}
    </div>
  );
}

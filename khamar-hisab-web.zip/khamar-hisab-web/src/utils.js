export const todayStr = () => new Date().toISOString().slice(0, 10);

export const taka = (n) => "৳" + (Number(n) || 0).toLocaleString("en-US", { maximumFractionDigits: 0 });

export const sum = (arr, f) => arr.reduce((a, b) => a + (Number(f(b)) || 0), 0);

export const sortByDateDesc = (arr) => [...arr].sort((a, b) => (a.date < b.date ? 1 : -1));

import React from "react";
import { Plus, Phone } from "lucide-react";
import { T, FARMS } from "../theme";
import { taka } from "../utils";
import { PageFrame, SectionHeader, Field, TextInput, LedgerButton, RuledRow, TwoStepDelete, PdfButton, EditGate, EmptyNote } from "./ui";

export default function MembersPage({
  members,
  memberForm,
  setMemberForm,
  addMember,
  removeMember,
  memberTotalCapital,
  memberCapital,
  isEditor,
  onRequestUnlock,
  requestPrint,
}) {
  const printAll = () =>
    requestPrint({
      title: "সদস্যদের তালিকা",
      sections: [
        {
          table: {
            columns: [
              { key: "name", label: "নাম" },
              { key: "phone", label: "মোবাইল" },
              { key: "joinDate", label: "যোগদান" },
              { key: "capital", label: "সর্বমোট মূলধন" },
            ],
            rows: members.map((m) => ({ name: m.name, phone: m.phone || "-", joinDate: m.joinDate, capital: taka(memberTotalCapital(m.id)) })),
          },
        },
      ],
    });

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <PageFrame>
        <EditGate isEditor={isEditor} onRequestUnlock={onRequestUnlock} />
        {isEditor && (
          <div style={{ padding: 14, display: "flex", flexWrap: "wrap", gap: 10, alignItems: "flex-end" }}>
            <Field label="নাম">
              <TextInput value={memberForm.name} onChange={(e) => setMemberForm({ ...memberForm, name: e.target.value })} placeholder="সদস্যের নাম" />
            </Field>
            <Field label="মোবাইল নম্বর">
              <TextInput value={memberForm.phone} onChange={(e) => setMemberForm({ ...memberForm, phone: e.target.value })} placeholder="০১XXXXXXXXX" />
            </Field>
            <Field label="যোগদানের তারিখ">
              <TextInput type="date" value={memberForm.joinDate} onChange={(e) => setMemberForm({ ...memberForm, joinDate: e.target.value })} />
            </Field>
            <LedgerButton onClick={addMember} color={T.gold}>
              <Plus size={15} /> সদস্য যোগ করুন
            </LedgerButton>
          </div>
        )}
      </PageFrame>

      <PageFrame>
        <SectionHeader title="সদস্যদের তালিকা" right={<PdfButton onClick={printAll} color={T.gold} />} />
        {members.length === 0 ? (
          <EmptyNote text="এখনও কোনো সদস্য যোগ করা হয়নি।" />
        ) : (
          members.map((m, i) => (
            <RuledRow key={m.id} index={i} style={{ flexWrap: "wrap" }}>
              <div style={{ flex: "1 1 140px" }}>
                <div style={{ fontWeight: 600 }}>{m.name}</div>
                <div style={{ fontSize: 12, color: T.inkSoft, display: "flex", alignItems: "center", gap: 4 }}>
                  {m.phone ? (
                    <>
                      <Phone size={11} /> {m.phone}
                    </>
                  ) : (
                    "—"
                  )}
                </div>
              </div>
              <div style={{ fontSize: 12, color: T.inkSoft, width: 100 }}>যোগদান: {m.joinDate}</div>
              <div style={{ textAlign: "right", width: 110 }}>
                <div style={{ fontSize: 11, color: T.inkSoft }}>সর্বমোট মূলধন</div>
                <div style={{ fontWeight: 700, fontVariantNumeric: "tabular-nums" }}>{taka(memberTotalCapital(m.id))}</div>
              </div>
              {isEditor && <TwoStepDelete onConfirm={() => removeMember(m.id)} />}
            </RuledRow>
          ))
        )}
      </PageFrame>

      {members.length > 0 && (
        <PageFrame>
          <SectionHeader title="খামারভিত্তিক মূলধনের বিস্তারিত" />
          {members.map((m, i) => (
            <RuledRow key={m.id} index={i}>
              <span style={{ flex: 1 }}>{m.name}</span>
              {Object.entries(FARMS).map(([k, f]) => (
                <span key={k} style={{ fontSize: 12, color: f.color, width: 78, textAlign: "right", fontVariantNumeric: "tabular-nums" }}>
                  {taka(memberCapital(m.id, k))}
                </span>
              ))}
            </RuledRow>
          ))}
          <div style={{ display: "flex", padding: "6px 16px 12px", fontSize: 11, color: T.inkSoft }}>
            <span style={{ flex: 1 }}></span>
            {Object.values(FARMS).map((f, i) => (
              <span key={i} style={{ width: 78, textAlign: "right" }}>
                {f.label.split(" ")[0]}
              </span>
            ))}
          </div>
        </PageFrame>
      )}
    </div>
  );
}

import React from "react";
import { T } from "../theme";
import LedgerTab from "./LedgerTab";
import MoneyTab from "./MoneyTab";
import ReportTab from "./ReportTab";

export default function FarmPage({
  farmKey,
  farm,
  totals,
  records,
  members,
  subTab,
  setSubTab,
  addItem,
  removeItem,
  clearAll,
  memberCapital,
  isEditor,
  onRequestUnlock,
  requestPrint,
}) {
  const subTabs = [
    { key: "ledger", label: "জমা/উত্তোলন" },
    { key: "expense", label: "খরচ" },
    { key: "income", label: "আয়" },
    { key: "report", label: "রিপোর্ট" },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <div style={{ display: "flex", gap: 4, borderBottom: `1px solid ${T.border}`, overflowX: "auto" }}>
        {subTabs.map((s) => (
          <button
            key={s.key}
            onClick={() => setSubTab(s.key)}
            style={{
              border: "none",
              background: "transparent",
              padding: "8px 12px",
              fontSize: 13.5,
              fontWeight: 600,
              cursor: "pointer",
              color: subTab === s.key ? farm.color : T.inkSoft,
              borderBottom: subTab === s.key ? `2.5px solid ${farm.color}` : "2.5px solid transparent",
              fontFamily: "'Hind Siliguri', sans-serif",
              whiteSpace: "nowrap",
            }}
          >
            {s.label}
          </button>
        ))}
      </div>

      {subTab === "ledger" && (
        <LedgerTab
          farm={farm}
          farmKey={farmKey}
          records={records}
          members={members}
          addItem={addItem}
          removeItem={removeItem}
          clearAll={clearAll}
          memberCapital={memberCapital}
          isEditor={isEditor}
          onRequestUnlock={onRequestUnlock}
          requestPrint={requestPrint}
        />
      )}
      {subTab === "expense" && (
        <MoneyTab
          type="expense"
          farm={farm}
          farmKey={farmKey}
          items={records.expenses}
          categories={farm.expenseCats}
          addItem={addItem}
          removeItem={removeItem}
          clearAll={clearAll}
          isEditor={isEditor}
          onRequestUnlock={onRequestUnlock}
          requestPrint={requestPrint}
        />
      )}
      {subTab === "income" && (
        <MoneyTab
          type="income"
          farm={farm}
          farmKey={farmKey}
          items={records.incomes}
          categories={farm.incomeCats}
          addItem={addItem}
          removeItem={removeItem}
          clearAll={clearAll}
          isEditor={isEditor}
          onRequestUnlock={onRequestUnlock}
          requestPrint={requestPrint}
        />
      )}
      {subTab === "report" && (
        <ReportTab
          farm={farm}
          farmKey={farmKey}
          totals={totals}
          records={records}
          members={members}
          memberCapital={memberCapital}
          requestPrint={requestPrint}
        />
      )}
    </div>
  );
}

import React from "react";
import { BarChart, Bar, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { T } from "../theme";
import { taka, sortByDateDesc } from "../utils";
import { PageFrame, SectionHeader, PdfButton, Metric, RuledRow, EmptyNote } from "./ui";

export default function ReportTab({ farm, farmKey, totals, records, members, memberCapital, requestPrint }) {
  const chartData = [
    { name: "আয়", পরিমাণ: totals.income, fill: farm.color },
    { name: "খরচ", পরিমাণ: totals.expense, fill: T.danger },
  ];

  const nameOf = (id) => members.find((m) => m.id === id)?.name || "অজানা সদস্য";

  const printReport = () => {
    const deposits = sortByDateDesc(records.deposits);
    const expenses = sortByDateDesc(records.expenses);
    const incomes = sortByDateDesc(records.incomes);

    requestPrint({
      title: `${farm.label} — লাভ-ক্ষতির রিপোর্ট`,
      sections: [
        {
          summaryRows: [
            ["মোট জমা", taka(totals.deposit)],
            ["মোট উত্তোলন", taka(totals.withdraw)],
            ["সদস্য-মূলধন (নিট)", taka(totals.capital)],
            ["মোট আয়", taka(totals.income)],
            ["মোট খরচ", taka(totals.expense)],
            ["নিট লাভ/ক্ষতি", taka(totals.profit)],
          ],
        },
        {
          heading: "সদস্য অনুযায়ী মূলধন",
          tables: members.length
            ? [
                {
                  columns: [
                    { key: "name", label: "নাম" },
                    { key: "capital", label: "মূলধন" },
                  ],
                  rows: members.map((m) => ({ name: m.name, capital: taka(memberCapital(m.id, farmKey)) })),
                },
              ]
            : [],
        },
        {
          heading: "বিস্তারিত হিসাব",
          tables: [
            deposits.length
              ? {
                  title: "জমা/উত্তোলন",
                  columns: [
                    { key: "date", label: "তারিখ" },
                    { key: "name", label: "সদস্য" },
                    { key: "type", label: "ধরন" },
                    { key: "amount", label: "পরিমাণ" },
                  ],
                  rows: deposits.map((d) => ({ date: d.date, name: nameOf(d.memberId), type: d.type, amount: taka(d.amount) })),
                }
              : null,
            expenses.length
              ? {
                  title: "খরচ",
                  columns: [
                    { key: "date", label: "তারিখ" },
                    { key: "category", label: "খাত" },
                    { key: "amount", label: "পরিমাণ" },
                  ],
                  rows: expenses.map((e) => ({ date: e.date, category: e.category, amount: taka(e.amount) })),
                }
              : null,
            incomes.length
              ? {
                  title: "আয়",
                  columns: [
                    { key: "date", label: "তারিখ" },
                    { key: "category", label: "খাত" },
                    { key: "amount", label: "পরিমাণ" },
                  ],
                  rows: incomes.map((inc) => ({ date: inc.date, category: inc.category, amount: taka(inc.amount) })),
                }
              : null,
          ].filter(Boolean),
        },
      ],
    });
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <PageFrame>
        <SectionHeader title={`${farm.label} — রিপোর্ট`} right={<PdfButton onClick={printReport} color={farm.color} />} />
        <div style={{ padding: 16, display: "flex", flexWrap: "wrap", gap: 20 }}>
          <Metric label="মোট জমা" value={taka(totals.deposit)} />
          <Metric label="মোট উত্তোলন" value={taka(totals.withdraw)} />
          <Metric label="সদস্য-মূলধন (নিট)" value={taka(totals.capital)} bold />
          <Metric label="মোট আয়" value={taka(totals.income)} />
          <Metric label="মোট খরচ" value={taka(totals.expense)} />
          <Metric label="নিট লাভ/ক্ষতি" value={taka(totals.profit)} color={totals.profit >= 0 ? T.goat : T.danger} bold />
        </div>
      </PageFrame>

      <PageFrame>
        <SectionHeader title="আয় বনাম খরচ" />
        <div style={{ height: 200, padding: "8px 8px 12px" }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={T.border} vertical={false} />
              <XAxis dataKey="name" tick={{ fill: T.ink, fontSize: 13 }} axisLine={{ stroke: T.border }} tickLine={false} />
              <YAxis tick={{ fill: T.inkSoft, fontSize: 11 }} axisLine={false} tickLine={false} width={54} />
              <Tooltip formatter={(v) => taka(v)} contentStyle={{ fontSize: 12, fontFamily: "'Hind Siliguri', sans-serif" }} />
              <Bar dataKey="পরিমাণ" radius={[3, 3, 0, 0]}>
                {chartData.map((d, i) => (
                  <Cell key={i} fill={d.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </PageFrame>

      <PageFrame>
        <SectionHeader title={`সদস্য অনুযায়ী মূলধন — ${farm.label}`} />
        {members.length === 0 ? (
          <EmptyNote text="কোনো সদস্য নেই।" />
        ) : (
          members.map((m, i) => (
            <RuledRow key={m.id} index={i}>
              <span style={{ flex: 1 }}>{m.name}</span>
              <span style={{ fontWeight: 700, fontVariantNumeric: "tabular-nums" }}>{taka(memberCapital(m.id, farmKey))}</span>
            </RuledRow>
          ))
        )}
      </PageFrame>
    </div>
  );
}

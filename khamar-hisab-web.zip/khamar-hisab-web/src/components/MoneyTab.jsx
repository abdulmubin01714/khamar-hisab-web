import React, { useState } from "react";
import { Plus } from "lucide-react";
import { T } from "../theme";
import { taka, todayStr, sortByDateDesc, sum } from "../utils";
import {
  PageFrame,
  SectionHeader,
  Field,
  TextInput,
  SelectInput,
  LedgerButton,
  RuledRow,
  TwoStepDelete,
  TwoStepBulk,
  PdfButton,
  EditGate,
  EmptyNote,
} from "./ui";

export default function MoneyTab({ type, farm, farmKey, items, categories, addItem, removeItem, clearAll, isEditor, onRequestUnlock, requestPrint }) {
  const isExpense = type === "expense";
  const sub = isExpense ? "expenses" : "incomes";
  const [form, setForm] = useState({ category: categories[0], amount: "", date: todayStr(), note: "" });

  const add = () => {
    if (!isEditor || !form.amount) return;
    addItem(farmKey, sub, { ...form, amount: Number(form.amount) });
    setForm({ ...form, amount: "", note: "" });
  };

  const sorted = sortByDateDesc(items);
  const total = sum(items, (it) => it.amount);

  const printAll = () =>
    requestPrint({
      title: `${farm.label} — ${isExpense ? "খরচের হিসাব" : "আয়ের হিসাব"}`,
      sections: [
        {
          table: {
            columns: [
              { key: "date", label: "তারিখ" },
              { key: "category", label: "খাত" },
              { key: "amount", label: "পরিমাণ" },
              { key: "note", label: "নোট" },
            ],
            rows: sorted.map((it) => ({ date: it.date, category: it.category, amount: taka(it.amount), note: it.note || "" })),
          },
        },
      ],
    });

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <PageFrame>
        <EditGate isEditor={isEditor} onRequestUnlock={onRequestUnlock} />
        {isEditor && (
          <div style={{ padding: 14, display: "flex", flexWrap: "wrap", gap: 10, alignItems: "flex-end" }}>
            <Field label="খাত">
              <SelectInput value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </SelectInput>
            </Field>
            <Field label="পরিমাণ (৳)">
              <TextInput type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="০" />
            </Field>
            <Field label="তারিখ">
              <TextInput type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            </Field>
            <Field label="নোট (ঐচ্ছিক)">
              <TextInput value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} placeholder="মন্তব্য" />
            </Field>
            <LedgerButton onClick={add} color={isExpense ? T.danger : farm.color}>
              <Plus size={15} /> যোগ করুন
            </LedgerButton>
          </div>
        )}
      </PageFrame>

      <PageFrame>
        <SectionHeader
          title={isExpense ? "খরচের তালিকা" : "আয়ের তালিকা"}
          right={
            <div style={{ display: "flex", gap: 8 }}>
              <PdfButton onClick={printAll} color={isExpense ? T.danger : farm.color} />
              {isEditor && sorted.length > 0 && <TwoStepBulk onConfirm={() => clearAll(sub, items.map((it) => it.id))} />}
            </div>
          }
        />
        {sorted.length === 0 ? (
          <EmptyNote text={isExpense ? "এখনও কোনো খরচ যোগ করা হয়নি।" : "এখনও কোনো আয় যোগ করা হয়নি।"} />
        ) : (
          <>
            {sorted.map((it, i) => (
              <RuledRow key={it.id} index={i}>
                <span style={{ width: 84, color: T.inkSoft, fontSize: 12.5 }}>{it.date}</span>
                <span style={{ flex: 1 }}>
                  {it.category}
                  {it.note ? <span style={{ color: T.inkSoft }}> — {it.note}</span> : null}
                </span>
                <span style={{ fontWeight: 700, color: isExpense ? T.danger : T.goat, fontVariantNumeric: "tabular-nums" }}>{taka(it.amount)}</span>
                {isEditor && <TwoStepDelete onConfirm={() => removeItem(farmKey, sub, it.id)} />}
              </RuledRow>
            ))}
            <div style={{ display: "flex", padding: "10px 16px", fontWeight: 700, fontSize: 14 }}>
              <span style={{ flex: 1 }}>মোট</span>
              <span style={{ fontVariantNumeric: "tabular-nums" }}>{taka(total)}</span>
            </div>
          </>
        )}
      </PageFrame>
    </div>
  );
}

import React from "react";
import { Users, Wallet, TrendingUp, TrendingDown } from "lucide-react";
import { T, FARMS } from "../theme";
import { taka } from "../utils";
import { PageFrame, SectionHeader, PdfButton, SummaryStat, Metric } from "./ui";

export default function Dashboard({ totals, memberCount, onDownloadFull }) {
  const grand = Object.values(totals).reduce(
    (a, t) => ({ capital: a.capital + t.capital, income: a.income + t.income, expense: a.expense + t.expense, profit: a.profit + t.profit }),
    { capital: 0, income: 0, expense: 0, profit: 0 }
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <PageFrame>
        <SectionHeader title="সব খামার একসাথে" right={<PdfButton onClick={onDownloadFull} color={T.neutral} />} />
        <div style={{ padding: "14px 16px 14px 20px", display: "flex", flexWrap: "wrap", gap: 18 }}>
          <SummaryStat label="মোট সদস্য" value={memberCount.toString()} color={T.gold} icon={Users} />
          <SummaryStat label="সর্বমোট সদস্য-মূলধন" value={taka(grand.capital)} color={T.neutral} icon={Wallet} />
          <SummaryStat
            label="সর্বমোট লাভ/ক্ষতি"
            value={taka(grand.profit)}
            color={grand.profit >= 0 ? T.goat : T.danger}
            icon={grand.profit >= 0 ? TrendingUp : TrendingDown}
          />
        </div>
        <div style={{ padding: "0 16px 14px", fontSize: 12, color: T.inkSoft }}>
          "PDF ডাউনলোড" বাটনে চাপলে গরু, মুরগি ও ছাগল — তিনটি খামারের সম্পূর্ণ হিসাব এক PDF-এ পাবেন।
        </div>
      </PageFrame>

      {Object.entries(FARMS).map(([key, farm]) => {
        const t = totals[key];
        return (
          <PageFrame key={key}>
            <div style={{ display: "flex" }}>
              <div style={{ width: 6, background: farm.color }} />
              <div style={{ flex: 1, padding: "12px 14px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                  <farm.icon size={17} color={farm.color} />
                  <span style={{ fontFamily: "'Tiro Bangla', serif", fontSize: 16.5 }}>{farm.label}</span>
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 16, fontSize: 13.5 }}>
                  <Metric label="সদস্য-মূলধন" value={taka(t.capital)} />
                  <Metric label="মোট আয়" value={taka(t.income)} />
                  <Metric label="মোট খরচ" value={taka(t.expense)} />
                  <Metric label="নিট লাভ/ক্ষতি" value={taka(t.profit)} color={t.profit >= 0 ? T.goat : T.danger} bold />
                </div>
              </div>
            </div>
          </PageFrame>
        );
      })}
    </div>
  );
}

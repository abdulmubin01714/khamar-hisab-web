import React, { useState } from "react";
import { Plus, MessageCircle } from "lucide-react";
import { T } from "../theme";
import { PageFrame, SectionHeader, Field, TextInput, LedgerButton, RuledRow, TwoStepDelete, TwoStepBulk, PdfButton, EditGate, EmptyNote } from "./ui";

export default function WhatsAppTab({ items, addItem, removeItem, clearAll, isEditor, onRequestUnlock, requestPrint }) {
  const [form, setForm] = useState({ name: "", number: "", note: "" });

  const add = () => {
    if (!isEditor || !form.name.trim() || !form.number.trim()) return;
    addItem(form);
    setForm({ name: "", number: "", note: "" });
  };

  const printAll = () =>
    requestPrint({
      title: "WhatsApp নাম্বারের তালিকা",
      sections: [
        {
          table: {
            columns: [
              { key: "name", label: "নাম" },
              { key: "number", label: "WhatsApp নাম্বার" },
              { key: "note", label: "নোট" },
            ],
            rows: items.map((it) => ({ name: it.name, number: it.number, note: it.note || "" })),
          },
        },
      ],
    });

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <PageFrame>
        <EditGate isEditor={isEditor} onRequestUnlock={onRequestUnlock} />
        {isEditor && (
          <div style={{ padding: 14, display: "flex", flexWrap: "wrap", gap: 10, alignItems: "flex-end" }}>
            <Field label="নাম">
              <TextInput value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="নাম" />
            </Field>
            <Field label="WhatsApp নাম্বার">
              <TextInput value={form.number} onChange={(e) => setForm({ ...form, number: e.target.value })} placeholder="+৮৮০১XXXXXXXXX" />
            </Field>
            <Field label="নোট (ঐচ্ছিক)">
              <TextInput value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} placeholder="যেমন: সভাপতি" />
            </Field>
            <LedgerButton onClick={add} color={T.whatsapp}>
              <Plus size={15} /> যোগ করুন
            </LedgerButton>
          </div>
        )}
      </PageFrame>

      <PageFrame>
        <SectionHeader
          title="WhatsApp নাম্বার তালিকা"
          right={
            <div style={{ display: "flex", gap: 8 }}>
              <PdfButton onClick={printAll} color={T.whatsapp} />
              {isEditor && items.length > 0 && <TwoStepBulk onConfirm={() => clearAll(items.map((it) => it.id))} />}
            </div>
          }
        />
        {items.length === 0 ? (
          <EmptyNote text="এখনও কোনো নাম্বার যোগ করা হয়নি।" />
        ) : (
          items.map((it, i) => (
            <RuledRow key={it.id} index={i}>
              <MessageCircle size={15} color={T.whatsapp} />
              <span style={{ flex: 1 }}>
                {it.name}
                {it.note ? <span style={{ color: T.inkSoft }}> — {it.note}</span> : null}
              </span>
              <span style={{ fontVariantNumeric: "tabular-nums", color: T.inkSoft }}>{it.number}</span>
              {isEditor && <TwoStepDelete onConfirm={() => removeItem(it.id)} />}
            </RuledRow>
          ))
        )}
      </PageFrame>
    </div>
  );
}

import React from "react";

function PrintTable({ title, columns, rows }) {
  if (!rows || rows.length === 0) return null;
  return (
    <div style={{ marginTop: 8, marginBottom: 14 }}>
      {title && <div style={{ fontWeight: 600, fontSize: 13, margin: "6px 0 4px" }}>{title}</div>}
      <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "'Hind Siliguri', sans-serif", fontSize: 12.5 }}>
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} style={{ textAlign: "left", borderBottom: "2px solid #333", padding: "4px 7px" }}>
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              {columns.map((c) => (
                <td key={c.key} style={{ borderBottom: "1px solid #ccc", padding: "4px 7px" }}>
                  {r[c.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function PrintSummaryGrid({ rows }) {
  if (!rows || rows.length === 0) return null;
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(3, minmax(140px,1fr))",
        gap: "4px 18px",
        margin: "6px 0 10px",
        fontFamily: "'Hind Siliguri', sans-serif",
        fontSize: 12.5,
      }}
    >
      {rows.map(([label, value], i) => (
        <div key={i} style={{ display: "flex", justifyContent: "space-between", borderBottom: "1px dotted #bbb", padding: "2px 0" }}>
          <span style={{ color: "#555" }}>{label}</span>
          <span style={{ fontWeight: 700, marginLeft: 8 }}>{value}</span>
        </div>
      ))}
    </div>
  );
}

export default function PrintArea({ job }) {
  if (!job) return null;
  return (
    <div className="print-area">
      <h2 style={{ fontFamily: "'Tiro Bangla', serif", marginBottom: 2 }}>হিসাবের খাতা</h2>
      {job.title && (
        <h3 style={{ fontFamily: "'Hind Siliguri', sans-serif", fontWeight: 600, marginTop: 0, color: "#444" }}>{job.title}</h3>
      )}
      {job.sections.map((sec, si) => (
        <div key={si} style={{ marginBottom: 18, pageBreakInside: "avoid" }}>
          {sec.heading && (
            <h4
              style={{
                fontFamily: "'Tiro Bangla', serif",
                fontSize: 15,
                borderBottom: "1px solid #999",
                paddingBottom: 4,
                marginBottom: 6,
              }}
            >
              {sec.heading}
            </h4>
          )}
          <PrintSummaryGrid rows={sec.summaryRows} />
          {sec.table && <PrintTable title={sec.table.title} columns={sec.table.columns} rows={sec.table.rows} />}
          {sec.tables && sec.tables.map((t, ti) => <PrintTable key={ti} title={t.title} columns={t.columns} rows={t.rows} />)}
        </div>
      ))}
      <div style={{ marginTop: 10, fontSize: 11, color: "#666" }}>তৈরি হয়েছে: {new Date().toLocaleString("bn-BD")}</div>
    </div>
  );
}

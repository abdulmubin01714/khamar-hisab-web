import React, { useState, useEffect } from "react";
import { Trash2, Download, Lock } from "lucide-react";
import { T } from "../theme";

export function Field({ label, children }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 4, flex: "1 1 130px", minWidth: 110 }}>
      <span style={{ fontSize: 12.5, color: T.inkSoft }}>{label}</span>
      {children}
    </label>
  );
}

const inputStyle = {
  border: "none",
  borderBottom: `1.5px solid ${T.border}`,
  background: "transparent",
  padding: "6px 2px",
  fontSize: 14.5,
  color: T.ink,
  fontFamily: "'Hind Siliguri', sans-serif",
  outline: "none",
  width: "100%",
};

export function TextInput(props) {
  return <input {...props} style={{ ...inputStyle, ...(props.style || {}) }} />;
}
export function SelectInput(props) {
  return (
    <select {...props} style={{ ...inputStyle, ...(props.style || {}) }}>
      {props.children}
    </select>
  );
}

export function LedgerButton({ children, onClick, color = T.neutral, style, disabled }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        background: disabled ? T.border : color,
        color: "#FFFDF7",
        border: "none",
        borderRadius: 3,
        padding: "8px 16px",
        fontSize: 14,
        fontFamily: "'Hind Siliguri', sans-serif",
        fontWeight: 600,
        cursor: disabled ? "not-allowed" : "pointer",
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      {children}
    </button>
  );
}

export function TwoStepDelete({ onConfirm }) {
  const [armed, setArmed] = useState(false);
  useEffect(() => {
    if (!armed) return;
    const t = setTimeout(() => setArmed(false), 2500);
    return () => clearTimeout(t);
  }, [armed]);
  return armed ? (
    <button
      onClick={onConfirm}
      style={{
        border: `1px solid ${T.danger}`,
        background: T.danger,
        color: "#fff",
        borderRadius: 3,
        padding: "4px 8px",
        fontSize: 12.5,
        cursor: "pointer",
        fontFamily: "'Hind Siliguri', sans-serif",
      }}
    >
      নিশ্চিত?
    </button>
  ) : (
    <button
      onClick={() => setArmed(true)}
      title="মুছুন"
      style={{ border: "none", background: "transparent", color: T.inkSoft, cursor: "pointer", padding: 4, display: "flex" }}
    >
      <Trash2 size={16} />
    </button>
  );
}

export function TwoStepBulk({ onConfirm, label = "সব মুছুন" }) {
  const [armed, setArmed] = useState(false);
  useEffect(() => {
    if (!armed) return;
    const t = setTimeout(() => setArmed(false), 3000);
    return () => clearTimeout(t);
  }, [armed]);
  return (
    <button
      onClick={() => (armed ? onConfirm() : setArmed(true))}
      style={{
        border: `1px solid ${armed ? T.danger : T.border}`,
        background: armed ? T.danger : "transparent",
        color: armed ? "#fff" : T.inkSoft,
        borderRadius: 3,
        padding: "6px 10px",
        fontSize: 12.5,
        cursor: "pointer",
        fontFamily: "'Hind Siliguri', sans-serif",
        display: "inline-flex",
        alignItems: "center",
        gap: 5,
      }}
    >
      <Trash2 size={13} /> {armed ? "নিশ্চিত করুন?" : label}
    </button>
  );
}

export function PdfButton({ onClick, color = T.neutral }) {
  return (
    <button
      onClick={onClick}
      style={{
        border: `1px solid ${color}`,
        background: "transparent",
        color,
        borderRadius: 3,
        padding: "6px 10px",
        fontSize: 12.5,
        cursor: "pointer",
        fontFamily: "'Hind Siliguri', sans-serif",
        display: "inline-flex",
        alignItems: "center",
        gap: 5,
        fontWeight: 600,
      }}
    >
      <Download size={13} /> PDF ডাউনলোড
    </button>
  );
}

export function RuledRow({ index, children, style }) {
  const fifth = (index + 1) % 5 === 0;
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        padding: "8px 10px 8px 16px",
        borderBottom: `1px solid ${fifth ? T.margin + "55" : T.rule + "80"}`,
        fontSize: 14,
        color: T.ink,
        position: "relative",
        ...style,
      }}
    >
      <span style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 3, background: T.margin, opacity: 0.55 }} />
      {children}
    </div>
  );
}

export function PageFrame({ children }) {
  return (
    <div
      style={{
        background: `repeating-linear-gradient(${T.card}, ${T.card} 33px, ${T.rule}35 34px)`,
        border: `1px solid ${T.border}`,
        borderRadius: 4,
        boxShadow: "0 1px 3px rgba(60,45,20,0.08)",
        overflow: "hidden",
      }}
    >
      {children}
    </div>
  );
}

export function SectionHeader({ title, right }) {
  return (
    <div
      style={{
        padding: "10px 16px",
        fontSize: 13,
        color: T.inkSoft,
        borderBottom: `1px solid ${T.border}`,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 8,
        flexWrap: "wrap",
      }}
    >
      <span>{title}</span>
      {right}
    </div>
  );
}

export function EditGate({ isEditor, onRequestUnlock }) {
  if (isEditor) return null;
  return (
    <div
      style={{
        padding: "12px 16px",
        background: T.paperDark,
        borderBottom: `1px solid ${T.border}`,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 10,
        flexWrap: "wrap",
        fontSize: 13,
        color: T.inkSoft,
      }}
    >
      <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <Lock size={14} /> শুধু দেখার অনুমতি — যোগ/মুছা করতে PIN দিন
      </span>
      <button
        onClick={onRequestUnlock}
        style={{
          border: "none",
          background: T.gold,
          color: "#fff",
          borderRadius: 3,
          padding: "6px 12px",
          fontSize: 12.5,
          cursor: "pointer",
          fontWeight: 600,
          fontFamily: "'Hind Siliguri', sans-serif",
        }}
      >
        এডিট মোড চালু করুন
      </button>
    </div>
  );
}

export function EmptyNote({ text }) {
  return <div style={{ padding: "22px 16px", textAlign: "center", color: T.inkSoft, fontSize: 13.5 }}>{text}</div>;
}

export function Metric({ label, value, color, bold }) {
  return (
    <div>
      <div style={{ fontSize: 11.5, color: T.inkSoft }}>{label}</div>
      <div style={{ fontSize: 14.5, fontWeight: bold ? 700 : 600, color: color || T.ink, fontVariantNumeric: "tabular-nums" }}>{value}</div>
    </div>
  );
}

export function SummaryStat({ label, value, color, icon: Icon }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, flex: "1 1 150px" }}>
      <div style={{ width: 34, height: 34, borderRadius: "50%", background: color + "1c", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Icon size={17} color={color} />
      </div>
      <div>
        <div style={{ fontSize: 11.5, color: T.inkSoft }}>{label}</div>
        <div style={{ fontSize: 17, fontWeight: 700, color: T.ink, fontVariantNumeric: "tabular-nums" }}>{value}</div>
      </div>
    </div>
  );
}

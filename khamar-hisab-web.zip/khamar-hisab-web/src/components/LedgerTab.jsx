import React, { useState, useEffect } from "react";
import { Plus } from "lucide-react";
import { T } from "../theme";
import { taka, todayStr, sortByDateDesc } from "../utils";
import {
  PageFrame,
  SectionHeader,
  Field,
  TextInput,
  SelectInput,
  LedgerButton,
  RuledRow,
  TwoStepDelete,
  TwoStepBulk,
  PdfButton,
  EditGate,
  EmptyNote,
} from "./ui";

export default function LedgerTab({ farm, farmKey, records, members, addItem, removeItem, clearAll, memberCapital, isEditor, onRequestUnlock, requestPrint }) {
  const [form, setForm] = useState({ memberId: members[0]?.id || "", type: "জমা", amount: "", date: todayStr(), note: "" });

  useEffect(() => {
    if (!form.memberId && members[0]) setForm((f) => ({ ...f, memberId: members[0].id }));
  }, [members]); // eslint-disable-line

  const add = () => {
    if (!isEditor || !form.memberId || !form.amount) return;
    addItem(farmKey, "deposits", { ...form, amount: Number(form.amount) });
    setForm({ ...form, amount: "", note: "" });
  };

  const nameOf = (id) => members.find((m) => m.id === id)?.name || "অজানা সদস্য";
  const sorted = sortByDateDesc(records.deposits);

  const printAll = () =>
    requestPrint({
      title: `${farm.label} — জমা/উত্তোলনের হিসাব`,
      sections: [
        {
          table: {
            columns: [
              { key: "date", label: "তারিখ" },
              { key: "name", label: "সদস্য" },
              { key: "type", label: "ধরন" },
              { key: "amount", label: "পরিমাণ" },
              { key: "note", label: "নোট" },
            ],
            rows: sorted.map((d) => ({ date: d.date, name: nameOf(d.memberId), type: d.type, amount: taka(d.amount), note: d.note || "" })),
          },
        },
      ],
    });

  if (members.length === 0) {
    return <EmptyNote text="প্রথমে “সদস্যগণ” ট্যাব থেকে সদস্য যোগ করুন।" />;
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <PageFrame>
        <EditGate isEditor={isEditor} onRequestUnlock={onRequestUnlock} />
        {isEditor && (
          <div style={{ padding: 14, display: "flex", flexWrap: "wrap", gap: 10, alignItems: "flex-end" }}>
            <Field label="সদস্য">
              <SelectInput value={form.memberId} onChange={(e) => setForm({ ...form, memberId: e.target.value })}>
                {members.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </SelectInput>
            </Field>
            <Field label="ধরন">
              <SelectInput value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                <option value="জমা">জমা</option>
                <option value="উত্তোলন">উত্তোলন</option>
              </SelectInput>
            </Field>
            <Field label="পরিমাণ (৳)">
              <TextInput type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="০" />
            </Field>
            <Field label="তারিখ">
              <TextInput type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            </Field>
            <Field label="নোট (ঐচ্ছিক)">
              <TextInput value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} placeholder="মন্তব্য" />
            </Field>
            <LedgerButton onClick={add} color={farm.color}>
              <Plus size={15} /> যোগ করুন
            </LedgerButton>
          </div>
        )}
      </PageFrame>

      <PageFrame>
        <SectionHeader
          title="জমা/উত্তোলনের তালিকা"
          right={
            <div style={{ display: "flex", gap: 8 }}>
              <PdfButton onClick={printAll} color={farm.color} />
              {isEditor && sorted.length > 0 && <TwoStepBulk onConfirm={() => clearAll("deposits", records.deposits.map((d) => d.id))} />}
            </div>
          }
        />
        {sorted.length === 0 ? (
          <EmptyNote text="এখনও কোনো জমা/উত্তোলন যোগ করা হয়নি।" />
        ) : (
          sorted.map((d, i) => (
            <RuledRow key={d.id} index={i}>
              <span style={{ width: 84, color: T.inkSoft, fontSize: 12.5 }}>{d.date}</span>
              <span style={{ flex: 1 }}>
                {nameOf(d.memberId)}
                {d.note ? <span style={{ color: T.inkSoft }}> — {d.note}</span> : null}
              </span>
              <span style={{ fontWeight: 700, color: d.type === "জমা" ? T.goat : T.danger, fontVariantNumeric: "tabular-nums" }}>
                {d.type === "জমা" ? "+" : "−"}
                {taka(d.amount)}
              </span>
              {isEditor && <TwoStepDelete onConfirm={() => removeItem(farmKey, "deposits", d.id)} />}
            </RuledRow>
          ))
        )}
      </PageFrame>

      <PageFrame>
        <SectionHeader title={`সদস্য অনুযায়ী মূলধন — ${farm.label}`} />
        {members.map((m, i) => (
          <RuledRow key={m.id} index={i}>
            <span style={{ flex: 1 }}>{m.name}</span>
            <span style={{ fontWeight: 700, fontVariantNumeric: "tabular-nums" }}>{taka(memberCapital(m.id, farmKey))}</span>
          </RuledRow>
        ))}
      </PageFrame>
    </div>
  );
}

import React, { useState } from "react";
import { X } from "lucide-react";
import { T } from "../theme";
import { Field, TextInput, LedgerButton } from "./ui";

export default function PinModal({ mode, onClose, onSubmit, error }) {
  const [oldPin, setOldPin] = useState("");
  const [pin1, setPin1] = useState("");
  const [pin2, setPin2] = useState("");

  const titles = {
    setup: "খাতার জন্য একটি PIN সেট করুন",
    unlock: "এডিট করতে PIN দিন",
    change: "PIN পরিবর্তন করুন",
  };

  const submit = () => {
    if (mode === "unlock") onSubmit({ pin: pin1 });
    else if (mode === "setup") {
      if (pin1.length < 4) return onSubmit({ error: "কমপক্ষে ৪ সংখ্যার PIN দিন" });
      if (pin1 !== pin2) return onSubmit({ error: "দুটি PIN মিলছে না" });
      onSubmit({ newPin: pin1 });
    } else if (mode === "change") {
      if (pin1.length < 4) return onSubmit({ error: "কমপক্ষে ৪ সংখ্যার PIN দিন" });
      if (pin1 !== pin2) return onSubmit({ error: "দুটি PIN মিলছে না" });
      onSubmit({ oldPin, newPin: pin1 });
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(36,42,38,0.55)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 50,
        padding: 16,
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: T.card,
          borderRadius: 6,
          padding: 20,
          width: "100%",
          maxWidth: 320,
          fontFamily: "'Hind Siliguri', sans-serif",
          border: `1px solid ${T.border}`,
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <h3 style={{ margin: 0, fontFamily: "'Tiro Bangla', serif", fontSize: 17, color: T.ink }}>{titles[mode]}</h3>
          <button onClick={onClose} style={{ border: "none", background: "transparent", cursor: "pointer", color: T.inkSoft }}>
            <X size={18} />
          </button>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {mode === "change" && (
            <Field label="বর্তমান PIN">
              <TextInput type="password" inputMode="numeric" value={oldPin} onChange={(e) => setOldPin(e.target.value)} />
            </Field>
          )}
          {mode === "unlock" ? (
            <Field label="PIN">
              <TextInput
                type="password"
                inputMode="numeric"
                autoFocus
                value={pin1}
                onChange={(e) => setPin1(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && submit()}
              />
            </Field>
          ) : (
            <>
              <Field label="নতুন PIN (কমপক্ষে ৪ সংখ্যা)">
                <TextInput type="password" inputMode="numeric" value={pin1} onChange={(e) => setPin1(e.target.value)} />
              </Field>
              <Field label="নতুন PIN আবার দিন">
                <TextInput type="password" inputMode="numeric" value={pin2} onChange={(e) => setPin2(e.target.value)} />
              </Field>
            </>
          )}
          {error && <div style={{ color: T.danger, fontSize: 12.5 }}>{error}</div>}
          <LedgerButton onClick={submit} color={T.gold} style={{ justifyContent: "center", marginTop: 4 }}>
            নিশ্চিত করুন
          </LedgerButton>
          <p style={{ fontSize: 11, color: T.inkSoft, margin: "4px 0 0", lineHeight: 1.5 }}>
            লক্ষ্য রাখুন: এই PIN শুধু কারা এডিট করতে পারবে তা আলাদা করার জন্য একটি সহজ ব্যবস্থা। প্রকৃত ডেটাবেজ-স্তরের নিরাপত্তার জন্য
            Firestore security rules-এ আরও শক্তিশালী নিয়ম যোগ করা যায় (README দেখুন)।
          </p>
        </div>
      </div>
    </div>
  );
}

import { PawPrint, Egg } from "lucide-react";

/* গ্রাম্য হিসাবের-খাতা (ledger register) থিম */
export const T = {
  paper: "#F3EEDF",
  paperDark: "#EAE2CC",
  card: "#FFFDF7",
  rule: "#B9CFE0",
  margin: "#A63D40",
  ink: "#242A26",
  inkSoft: "#6B6252",
  gold: "#9C6B0F",
  border: "#DCD3B8",
  cow: "#8B5A2B",
  chicken: "#B07F1E",
  goat: "#3F6B4A",
  whatsapp: "#2A7A6B",
  neutral: "#3B4A55",
  danger: "#A63D40",
};

export const FARMS = {
  cow: {
    label: "গরুর খামার",
    color: T.cow,
    icon: PawPrint,
    expenseCats: ["গো-খাদ্য", "ওষুধ ও চিকিৎসা", "শ্রমিক মজুরি", "অন্যান্য"],
    incomeCats: ["দুধ বিক্রি", "পশু বিক্রি", "অন্যান্য"],
  },
  chicken: {
    label: "মুরগির ফার্ম",
    color: T.chicken,
    icon: Egg,
    expenseCats: ["মুরগির খাবার", "ওষুধ ও ভ্যাকসিন", "শ্রমিক মজুরি", "অন্যান্য"],
    incomeCats: ["ডিম বিক্রি", "মুরগি বিক্রি", "অন্যান্য"],
  },
  goat: {
    label: "ছাগলের ফার্ম",
    color: T.goat,
    icon: PawPrint,
    expenseCats: ["খাবার", "ওষুধ ও চিকিৎসা", "শ্রমিক মজুরি", "অন্যান্য"],
    incomeCats: ["ছাগল বিক্রি", "দুধ বিক্রি", "অন্যান্য"],
  },
};

export const emptyRecords = () => ({ deposits: [], expenses: [], incomes: [] });
